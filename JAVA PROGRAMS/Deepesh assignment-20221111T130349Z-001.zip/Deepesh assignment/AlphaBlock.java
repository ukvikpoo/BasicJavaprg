class AlphaBlock
{

		static void AlphaLine()
		{

			char c;

			for(c = 'A'; c <= 'F'; c++)
			{

				System.out.print(c);


			}



		}



	public static void main(String[] args)
	{ 

		for(int i= 1; i <= 7; i++)
		{

			System.out.println();
			AlphaLine();
		}

	}


}


