class Num1234Block
{
	
static void PrintLine()
{
		for(int i = 1; i <= 5; i++)
		{

			//System.out.println();
			System.out.print(i);


		}
}



public static void main(String[] args)
	{
		for(int j = 1; j <=5 ; j++)
		{

			PrintLine();
			System.out.println();
			//PrintLine();

		}
	}

}